test-image-glob
===============

.. image:: rimg.png

.. figure:: rimg.png

   The caption of pic

.. image:: img.*

.. figure:: img.*

   The caption of img
