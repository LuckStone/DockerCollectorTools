# -*- coding: utf-8 -*-

from sphinx.writers.html import HTMLTranslator

class ExtHTMLTranslator(HTMLTranslator):
    pass
