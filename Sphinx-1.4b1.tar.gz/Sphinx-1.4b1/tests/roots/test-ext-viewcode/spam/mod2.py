"""
mod2
"""

def func2(a, b):
    """
    this is func2
    """
    return a, b


class Class2(object):
    """
    this is Class2
    """
