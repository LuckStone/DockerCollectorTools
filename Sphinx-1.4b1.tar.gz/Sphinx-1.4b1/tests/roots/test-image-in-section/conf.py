# -*- coding: utf-8 -*-

master_doc = 'index'
exclude_patterns = ['_build']

rst_epilog = '''
.. |picture| image:: pic.png
    :width: 15pt
    :height: 15pt
    :alt: alternative_text
'''

