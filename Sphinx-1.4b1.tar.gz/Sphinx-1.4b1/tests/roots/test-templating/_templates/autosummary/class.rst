{% extends "!autosummary/class.rst" %}

{% block methods %}

   .. note:: autosummary/class.rst method block overloading

   {{ super() }}
{% endblock %}
