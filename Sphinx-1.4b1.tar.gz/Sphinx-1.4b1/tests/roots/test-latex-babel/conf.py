# -*- coding: utf-8 -*-

master_doc = 'index'
numfig_format = {
    'figure': 'Fig. %s',
    'table': 'Table. %s',
    'code-block': 'List.',
}
