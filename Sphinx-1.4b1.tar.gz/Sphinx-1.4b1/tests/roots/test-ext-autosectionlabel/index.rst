=========================
test-ext-autosectionlabel
=========================


Introduce of Sphinx
===================

Installation
============

For Windows users
-----------------

For UNIX users
--------------


References
==========

* :ref:`Introduce of Sphinx`
* :ref:`Installation`
* :ref:`For Windows users`
* :ref:`For UNIX users`
